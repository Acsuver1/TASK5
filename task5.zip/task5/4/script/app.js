

// task4 + task5 + ixtiyoriy

document.getElementById('productForm').addEventListener('submit', function(e) {
    e.preventDefault();

    let name = document.getElementById('name').value;
    let amount = document.getElementById('amount').value;
    let price = document.getElementById('price').value;

    let product = {
        name: name,
        amount: parseInt(amount),
        price: parseInt(price)
    };

    let products = [];
    if (localStorage.getItem('products')) {
        products = JSON.parse(localStorage.getItem('products'));
    }
    products.push(product);
    localStorage.setItem('products', JSON.stringify(products));

    alert('Mahsulot muvaffaqiyatli qo\'shildi!');

    document.getElementById('name').value = '';
    document.getElementById('amount').value = '';
    document.getElementById('price').value = '';

    renderProducts();
});

function renderProducts() {
    let productList = document.getElementById('productList');
    let productCount = document.getElementById('productCount');
    let totalCost = document.getElementById('totalCost');
    productList.innerHTML = '';

    let products = [];
    if (localStorage.getItem('products')) {
        products = JSON.parse(localStorage.getItem('products'));
    }

    let total = 0;
    products.forEach(function(product) {
        let li = document.createElement('li');
        li.innerHTML = `<strong>${product.name}</strong> - Miqdori: ${product.amount}, Narxi: ${product.price} so'm`;
        productList.appendChild(li);
        total += product.amount * product.price;
    });

    
    if (productList.children.length > 0) {
        productList.children[0].classList.add('special');
        productList.children[productList.children.length - 1].classList.add('special');
    }

    
    productCount.innerText = `Mahsulotlar soni: ${products.length}`;

   
    totalCost.innerText = `Umumiy qiymat: ${total} so'm`;
}

document.addEventListener('DOMContentLoaded', function() {
    renderProducts();
});



// local storage ga  yuklangan 