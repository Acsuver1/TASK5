

// task1 


let products = [];

document.getElementById('productForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    let name = document.getElementById('name').value;
    let amount = parseInt(document.getElementById('amount').value);
    let price = parseInt(document.getElementById('price').value);

    let product = {name, amount, price};
    products.push(product);
    
    displayProducts();
    clearForm();
});

function displayProducts() {
    let productList = document.getElementById('productList');
    productList.innerHTML = '';

    products.forEach((product, index) => {
        let li = document.createElement('li');
        li.textContent = `${product.name} - Miqdori: ${product.amount}, Narxi: ${product.price}`;
        productList.appendChild(li);
    });
}

function clearForm() {
    document.getElementById('name').value = '';
    document.getElementById('amount').value = '';
    document.getElementById('price').value = '';
}
